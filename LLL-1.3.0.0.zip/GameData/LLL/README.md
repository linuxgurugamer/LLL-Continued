LackLusterLabs SpaceBoxes Continuation

Development forum is here:  http://forum.kerbalspaceprogram.com/index.php?/topic/151603-121-lll-continued-dev-thread/

ModuleManager DLL included with permission of Sarbian
Module manager source is under a "CC share-alike license" under the term specified by ialdabaoth (http://forum.kerbalspaceprogram.com/threads/31342-0-20-ModuleManager-1-3-for-all-your-stock-modding-needs?p=528607&viewfull=1#post528607). He is the original creator of Module Manager.

The source code for this version is available here : https://github.com/sarbian/ModuleManager

